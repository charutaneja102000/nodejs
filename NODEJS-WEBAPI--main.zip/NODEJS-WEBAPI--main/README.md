# NODEJS-WEBAPI-
NodeJs web API deployed on aws

For Profile Role
https://us-east-1.console.aws.amazon.com/iamv2/home?region=us-east-1#/roles/create?step=selectEntities

Key Pairs
https://us-east-1.console.aws.amazon.com/ec2/home?region=us-east-1#KeyPairs:


CI/CD
<img width="956" alt="image" src="https://github.com/deeprajsinghsisodiya/NODEJS-WEBAPI-/assets/122676491/fbd4021a-368a-4326-925c-dc2a0c7a5b24">
Make sure you create app first with own code or skip uploading the code
Search codepipeline ---> follow easy instruction ----> Add git version two---->select Beanstalk-----> add app and environment...pipeline will be live in a minute 
